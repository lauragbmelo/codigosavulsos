<?php

header("Content-type: text/html; charset=utf8;");

// IMPORTAR A CLASSE USUARIO
require_once "CLASSES/Usuarios.php";

//CRIAR INSTANCIA DA CLASSE USUARIOS
$Usuarios = new Usuarios();

// TESTAR SE CLICOU NO BOTÃO LOGAR
if(isset($_POST["Logar"])){
    // CHAMAR FUNÇÃO DE LOGIN
    $Usuarios->login();
}

?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main>
        <h1>Fazer Login</h1>
        <form action="login.php" method="post">
            <label for="email">
                <span>E-mail</span>
                <input type="email" id="email" name="email" placeholder="email@email.com" required>
            </label>

            <label for="password">
                <span>Senha</span>
                <input type="password" id="senha" name="senha" placeholder="*****" required>
            </label>

            <input type="submit" value="Logar" id="Logar" name="Logar">
        </form>
    </main>
    <section class="images">
        <img src="img/mobile.svg" alt="Mobile">
        <div class="circle"></div>
    </section>
</body>
</html>