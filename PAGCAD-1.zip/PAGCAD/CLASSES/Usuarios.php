<?php 

require_once "Conexao.php";
class Usuarios
{
    //ATRIBUTOS 
    public $CODIGO;
    public $NOME;
    public $EMAIL;
    public $SENHA;


    public function inserir()
    {
        try {


            $this->EMAIL = $_POST["email"];
            $this->SENHA = $_POST["senha"];

            $bd = new Conexao();

            // criar a variavel para receber a conexao
            $con = $bd->conectar();

            //criar o comando para o sql ser executado no banco de dados
            $sql = $con->prepare("select * from usuarios where email = ? ");

            $sql->execute(array($this->EMAIL));
            $result=$sql->fetchObject();
            //$sql->debugDumpParams(); die();
            //testar se o comando deu certo
            if($sql->rowCount() < 1){ // abrir o if
            // var_dump($_POST);die();
            //TESTAR SE RECEBEU OS DADOS DO FORMULARIO
                if (isset($_POST["nome"]) && isset($_POST["email"])) {
                    // PREENCHER OS ATRIBUTOS COM DADOS DO FORM
                    $this->nome = $_POST["nome"];
                    $this->email = $_POST["email"];
                    $this->senha = $_POST["senha"];
                    //CRIAR UMA INSTANCIA DA CLASSE DE CONEXÃO
                    $bd = new Conexao();
                    //criar variavel para receber conexão
                    $con = $bd->conectar();
                    //Comnado sql para inseir aluinos
                    $sql = $con->prepare("insert into usuarios(codigo,nome,email,senha)
                                                    values(null,?,?,?);");
                    //EXECUTAR O COMANDO NO BANCO DE DADOS
                    $sql->execute(array(
                        $this->nome,
                        $this->email,
                        $this->senha
                    ));
                    //testar se o comando deu certo -> 0 isert deu errado / 1 ou mais insert deu certo
                    if ($sql->rowCount() > 0) {
                        //redirecionar usuario para tela de index
                        header("location: login.php");
                    }
                } else { // DEVOLVER O USUARIO PARA A TELA DE CADASTRO
                    header("location: registrar.php");                
                }
            }else{
                header("location:registrar.php");
            }
        } catch (PDOException $msg) {
            echo "Não foi possivel. {$msg->getMessage()}";
        }
    }






public function login()   {// abrir login 

    try{//abrir o try 
        // testar se recebeu o email e a senha 
        if(isset($_POST["email"]) && isset($_POST["senha"])){// abrir o if 
            //preencher os atributos com os valores recebidos da tela 
            $this->EMAIL = $_POST["email"];
            $this->SENHA = $_POST["senha"];

            // criar a instancia da classer conexao 
            $bd = new Conexao();

            // criar a variavel para receber a conexao 
            $con = $bd->conectar();

            //criar o comando para o sql ser executado no banco de dados 
            $sql = $con->prepare("select * from usuarios where email = ? and senha = ?");

            // executar o comando no banco de dados 
            $sql->execute(array($this->EMAIL, $this->SENHA));
            //$sql->debugDumpParams(); die();
            //testar se o comando deu certo

            if($sql->rowCount() > 0){ // abrir o if 
                $_SESSION["usuario"]= $sql->fetchObject();
                // login funcionou corretamente, usuario entra no sistema
                header("location: deu.php");

            }// fechar o if 

            else {
                // email ou senha incorretos 
                header("location: login.php");
               
            } 


        }// fechar o if
            else {// abrir o else 
                // nao recebeu nenhum, voltar para o index
             header("location: login.php");
            }// fechar o else 
   }// fechar o try 
   catch (PDOException $msg){
        echo "Não foi possivel fazer o login. {$msg->getMessage()}";
    }
   

}
}