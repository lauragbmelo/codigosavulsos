<?php
header("Content-type: text/html; charset=utf8;");
//IMPORTAR CLASSE USUARIO
require_once "CLASSES/Usuarios.php";

//CRIAR INSTANCIA DA CLASSE USUARIO
$Usuarios = new Usuarios();

//TESTAR SE CLICOU NO BOTÃO SALVAR
if(isset($_POST["Salvar"])){
    //CHAMAR FUNÇÃO INSERIR
    $Usuarios->inserir();
}

?>



<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main>
        <h1>Criar Conta</h1>
        <div class="social-media">
            <a href="#">
                <img src="img/google.png" alt="Google">
            </a>
            <a href="#">
                <img src="img/facebook.png" alt="Facebook">
            </a>
            <a href="#">
                <img src="img/linkedin.png" alt="Linkedin">
            </a>
        </div>

        <div class="alternative">
            <span>OR</span>
        </div>

        <form action="registrar.php" method="post">
            <label for="name">
                <span>Nome</span>
                <input type="text" id="nome" name="nome">
            </label>

            <label for="email">
                <span>E-mail</span>
                <input type="email" id="email" name="email">
            </label>

            <label for="password">
                <span>Senha</span>
                <input type="password" id="senha" name="senha">
            </label>

            <input type="submit" value="Sign Up" id="Salvar" name="Salvar">
        </form>
    </main>
    <section class="images">
        <img src="img/mobile.svg" alt="Mobile">
        <div class="circle"></div>
    </section>
</body>
</html>