<?php session_start();

class Conexao{
        // ATRIBUTOS PARA CRIAR UMA CONEXÃO SÃO: (SERVIDOR ; BANCO DE DADOS ; USUARIO ; SENHA);

    private $servidor;
    private $banco;
    private $usuario;
    private $senha;

    function __construct(){
        $this->servidor = "localhost";
        $this->banco = "teste";
        $this->usuario = "root";
        $this->senha = "";

    }

    public function conectar()
    {
        try {
            //CRIAR A CONEXÃO COM MSQL UTILIZANDO O PDO -> NEW -> CRIA UMA INSTANCIA DA CLASSE
            $con = new PDO("mysql:host={$this->servidor};dbname={$this->banco};charset=utf8;", $this->usuario, $this->senha);
            return $con;
        } catch (PDOException $msg) { // SE DER ERO RETORNA MSG
            echo "Não foi possivel conectar ao Banco de Dados {$msg->getMessage()}";
        }
    }
}